NodeMaster:
NodeMaster(例)を参考にして、ご自身の端末を設定してください